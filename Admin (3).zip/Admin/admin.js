// admin.js

function AddData() {
    var labialesStock = parseInt(document.getElementById('inputLabiales').value);
    var polvoStock = parseInt(document.getElementById('inputPolvo').value);
    var rimelStock = parseInt(document.getElementById('inputRimel').value);
    var desmaquillanteStock = parseInt(document.getElementById('inputDesmaquillante').value);
  
    if (isNaN(labialesStock) || isNaN(polvoStock) || isNaN(rimelStock) || isNaN(desmaquillanteStock)) {
      alert('Por favor, ingresa cantidades válidas.');
      return;
    }
  
    document.getElementById('inputLabiales').value = '';
    document.getElementById('inputPolvo').value = '';
    document.getElementById('inputRimel').value = '';
    document.getElementById('inputDesmaquillante').value = '';
  
    var table = document.getElementById('tabledata').getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.rows.length);
  
    var cellLabiales = newRow.insertCell(0);
    var cellPolvo = newRow.insertCell(1);
    var cellRimel = newRow.insertCell(2);
    var cellDesmaquillante = newRow.insertCell(3);
    var cellActions = newRow.insertCell(4);
  
    cellLabiales.innerHTML = labialesStock;
    cellPolvo.innerHTML = polvoStock;
    cellRimel.innerHTML = rimelStock;
    cellDesmaquillante.innerHTML = desmaquillanteStock;
  
    var btnRestar = document.createElement('button');
    btnRestar.innerHTML = 'Restar Stock';
    btnRestar.className = 'btn btn-danger btn-sm';
    btnRestar.onclick = function() {
      restarStock(labialesStock, polvoStock, rimelStock, desmaquillanteStock, newRow);
    };
  
    cellActions.appendChild(btnRestar);
  }
  
  function restarStock(labialesStock, polvoStock, rimelStock, desmaquillanteStock, row) {
    var cantidadARestar = prompt('Ingrese la cantidad a restar para cada producto:');
  
    cantidadARestar = parseInt(cantidadARestar);
    if (isNaN(cantidadARestar) || cantidadARestar <= 0) {
      alert('Por favor, ingresa una cantidad válida para restar.');
      return;
    }
  
    labialesStock -= cantidadARestar;
    polvoStock -= cantidadARestar;
    rimelStock -= cantidadARestar;
    desmaquillanteStock -= cantidadARestar;
  
    row.cells[0].innerHTML = labialesStock;
    row.cells[1].innerHTML = polvoStock;
    row.cells[2].innerHTML = rimelStock;
    row.cells[3].innerHTML = desmaquillanteStock;
  
    alert('Stock restado con éxito.');
  }
  
//Validar formulario
function ValidateForm() {
    let name = document.getElementById('inputName').value;
    let email = document.getElementById('inputEmail').value;
    let maquillaje = document.getElementById('ImputMaquillaje').value;
    let fechaCompra = document.getElementById('ImputCompra').value;
    let direccion = document.getElementById('ImputDireccion').value;
    let opciones = document.getElementById('ImputOpciones').value;

    if (name == "") {
        alert('Debe agregar un nombre');
        return false;
    }

    if (email == "") {
        alert('El campo correo es requerido');
        return false;
    } else if (!email.includes('@')) {
        alert('El correo no es válido');
        return false;
    }

    if (maquillaje == "") {
        alert('El campo maquillaje es requerido');
        return false;
    }

    if (fechaCompra == "") {
        alert('Debe agregar una Fecha de Compra');
        return false;
    }

    if (direccion == "") {
        alert('Debe agregar una Dirección');
        return false;
    }

    if (opciones == "") {
        alert('Debe agregar Opciones');
        return false;
    }

    return true;
}

// Leer datos y mostrar en la tabla
function ReadData() {
    let listPeople;

    if (localStorage.getItem('listPeople') == null) {
        listPeople = [];
    } else {
        listPeople = JSON.parse(localStorage.getItem('listPeople'));
    }

    var html = "";

    listPeople.forEach(function (element, index) {
        html += "<tr>";
        html += "<td>" + element.name + "</td>";
        html += "<td>" + element.email + "</td>";
        html += "<td>" + element.maquillaje + "</td>";
        html += "<td>" + element.fechaCompra + "</td>";
        html += "<td>" + element.direccion + "</td>";
        html += "<td>" + element.opciones + "</td>";
        html += '<td><button onclick="deleteData(' + index + ')" class="btn btn-danger">Eliminar Dato</button> <button onclick="editData(' + index + ')" class="btn btn-warning">Editar Dato</button>';
        html += "</tr>";
    });

    document.querySelector('#tableData tbody').innerHTML = html;
}

document.onload = ReadData();

// Agregar datos
function AddData() {
    if (ValidateForm() == true) {
        let name = document.getElementById('inputName').value;
        let email = document.getElementById('inputEmail').value;
        let maquillaje = document.getElementById('ImputMaquillaje').value;
        let fechaCompra = document.getElementById('ImputCompra').value;
        let direccion = document.getElementById('ImputDireccion').value;
        let opciones = document.getElementById('ImputOpciones').value;

        var listPeople;

        if (localStorage.getItem('listPeople') == null) {
            listPeople = [];
        } else {
            listPeople = JSON.parse(localStorage.getItem('listPeople'));
        }

        listPeople.push({
            name: name,
            email: email,
            maquillaje: maquillaje,
            fechaCompra: fechaCompra,
            direccion: direccion,
            opciones: opciones
        });

        localStorage.setItem('listPeople', JSON.stringify(listPeople));

        ReadData();

        // Limpiar campos
        document.getElementById('inputName').value = "";
        document.getElementById('inputEmail').value = "";
        document.getElementById('ImputMaquillaje').value = "";
        document.getElementById('ImputCompra').value = "";
        document.getElementById('ImputDireccion').value = "";
        document.getElementById('ImputOpciones').value = "";
    }
}

// Eliminar datos
function deleteData(indexClientes) {
    let listPeople;

    if (localStorage.getItem('listPeople') == null) {
        listPeople = [];
    } else {
        listPeople = JSON.parse(localStorage.getItem('listPeople'));
    }

    listPeople.splice(indexClientes, 1);
    localStorage.setItem('listPeople', JSON.stringify(listPeople));

    ReadData();
}

// Editar datos
function editData(indexClientes) {
    let listPeople;

    if (localStorage.getItem('listPeople') == null) {
        listPeople = [];
    } else {
        listPeople = JSON.parse(localStorage.getItem('listPeople'));
    }

    // Llenar campos con datos existentes
    document.getElementById('inputName').value = listPeople[indexClientes].name;
    document.getElementById('inputEmail').value = listPeople[indexClientes].email;
    document.getElementById('ImputMaquillaje').value = listPeople[indexClientes].maquillaje;
    document.getElementById('ImputCompra').value = listPeople[indexClientes].fechaCompra;
    document.getElementById('ImputDireccion').value = listPeople[indexClientes].direccion;
    document.getElementById('ImputOpciones').value = listPeople[indexClientes].opciones;

    // Actualizar datos al hacer clic en el botón de actualización
    document.querySelector('#BtnUpDate').onclick = function () {
        if (ValidateForm() == true) {
            listPeople[indexClientes].name = document.getElementById('inputName').value;
            listPeople[indexClientes].email = document.getElementById('inputEmail').value;
            listPeople[indexClientes].maquillaje = document.getElementById('ImputMaquillaje').value;
            listPeople[indexClientes].fechaCompra = document.getElementById('ImputCompra').value;
            listPeople[indexClientes].direccion = document.getElementById('ImputDireccion').value;
            listPeople[indexClientes].opciones = document.getElementById('ImputOpciones').value;

            localStorage.setItem('listPeople', JSON.stringify(listPeople));
            ReadData();

            // Limpiar campos
            document.getElementById('inputName').value = "";
            document.getElementById('inputEmail').value = "";
            document.getElementById('ImputMaquillaje').value = "";
            document.getElementById('ImputCompra').value = "";
            document.getElementById('ImputDireccion').value = "";
            document.getElementById('ImputOpciones').value = "";

            // Cambiar botones a su estado original
            document.getElementById('BtnAdd').style.display = 'block';
            document.getElementById('BtnUpDate').style.display = 'none';
        }
    };
}
